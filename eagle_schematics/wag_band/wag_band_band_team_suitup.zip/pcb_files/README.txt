Contact Information:
Chas Frick
Cell: 610-470-8097
Email: cjfrick@wpi.edu
Address: 4 Dean Street Apt 2. Worcester MA, 01609

PCB Files:
wgbnd_bottom_copper.GBL --> bottom copper for board

wgbnd_top_soldermask.GTS --> soldermask for top layer

wgbnd_top_silkscreen.GTO --> silkscreening for top layer

wgbnd_top_paste.GTP --> top layer paste

wgbnd_top_copper.GTL --> top copper for board

wgbnd_bottom_silkscreen.GBO --> bottom silkscreening for bottom layer

wgbnd_bottom_soldermask.GBS --> soldermask for the bottom layer

wgbnd_photoplotter_info_file.gpi --> Photoplotter info file

wgbnd_mill_layer.GML --> Mill layer for PCB

wgbnd_drillstation_info.dri --> drill station info file

wgbnd_NCDrill.drd --> NC Drill file


