CONTACT INFO:
Chas Frick
Cell: 610-470-8097
Email: cjfrick@wpi.edu
Address: 4 Dean Street Apt. 2, Worcester MA, 01609

PCB FILES:
wgnbdchst_drillstation_info.dri --> Drill Station Info File
wgbndchst_top_soldermask.GTS --> top soldermask info
wgbndchst_top_paste.GTP --> top paste file
wgbndchst_top_silkscreen.GTO --> top layer silkscreen info
wgbndchst_top_copper.GTL --> top layer copper info
wgbndchst_mill_layer.GML --> Drill File
wgbndchst_photoplotter_info.gpi --> Photoplotter info file
wgbndchst_bottom_silkscreen.GBO --> bottom layer silkscreen info
wgbndchst_bottom_soldermask.GBS --> bottom layer soldermask info
wgbndchst_bottom_copper.GBL --> bottom layer copper info